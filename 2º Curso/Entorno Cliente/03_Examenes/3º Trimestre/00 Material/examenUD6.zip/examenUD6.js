/*  
    Desarrollo web en entorno cliente
    DAW Distancia - Curso 24-25
    Examen UD6 - 250521
*/

document.addEventListener("DOMContentLoaded", function () {
  calculadora();

  function calculadora() {
    const display = document.getElementById("display");
    const historialLista = document.getElementById("historial");
    const botonDeshacer = document.getElementById("deshacer");

    let operacion = "";
    let ultimoNodo = null;

    function actualizarDisplay() {
      display.textContent = operacion || "0";
    }

    function agregar(valor) {
      operacion += valor;
      actualizarDisplay();
    }

    function borrar() {
      operacion = "";
      actualizarDisplay();
      borrarHistorial();
    }

    function retroceder() {
      operacion = operacion.slice(0, -1);
      actualizarDisplay();
    }

    function calcular() {
      try {
        const resultado = eval(
          operacion.replace(/×/g, "*").replace(/÷/g, "/")
        );
        agregarAlHistorial(`${operacion} = ${resultado}`);
        operacion = resultado.toString();
        actualizarDisplay();
      } catch (error) {
        operacion = "";
        display.textContent = "Error";
      }
    }

    // Ejercicio 1
    function agregarAlHistorial(texto) {


    }

    // Ejercicio 2
    function borrarHistorial() {



    }

    // Ejercicio 3
    function deshacer() {



    }

    document.querySelectorAll(".boton").forEach((boton) => {
      boton.addEventListener("click", () => {
        const valor = boton.textContent;
        switch (valor) {
          case "C":
            borrar();
            break;
          case "←":
            retroceder();
            break;
          case "=":
            calcular();
            break;
          default:
            agregar(valor);
            break;
        }
      });
    });

    botonDeshacer.addEventListener("click", deshacer);
  }
});

