/*  
    Desarrollo web en entorno cliente
    DAW Distancia - Curso 24-25
    Examen UD6 - 250521
*/

document.addEventListener("DOMContentLoaded", function () {
  calculadora();

  function calculadora() {
    const display = document.getElementById("display");
    const historialLista = document.getElementById("historial");
    const botonDeshacer = document.getElementById("deshacer");
   

    let operacion = "";
    let ultimoNodo = null;

    function actualizarDisplay() {
      display.textContent = operacion || "0";
    }

    function agregar(valor) {
      operacion += valor;
      actualizarDisplay();
    }

    function borrar() {
      operacion = "";
      actualizarDisplay();
      borrarHistorial();
    }

    function retroceder() {
      operacion = operacion.slice(0, -1);
      actualizarDisplay();
    }

    function calcular() {
      try {
        const resultado = eval(
          operacion.replace(/×/g, "*").replace(/÷/g, "/")
        );
        agregarAlHistorial(`${operacion} = ${resultado}`);
        operacion = resultado.toString();
        actualizarDisplay();
      } catch (error) {
        operacion = "";
        display.textContent = "Error";
      }
    }

    // Ejercicio 1
    function agregarAlHistorial(texto) {
      //const div = document.getElementsByClassName("enc"); 
      const linea = document.createElement('li');
      let resultado = document.createTextNode(texto);
      const lista = document.getElementById("historial");
      
      lista.appendChild(linea);
      //linea.textContent= resultado.value;
      linea.innerText=texto;
  
    }

    // Ejercicio 2
    function borrarHistorial() {
      const boton = queySelector("boton gris");
      

      const borrar = document.getElementById("dehacer");
      const lista = document.getElementById("historial")
      borrar.addEventListener("click",(eventoBorrar)=> {




        console.log ( " hey , estoy borrando los resultados")
      })


    }

    // Ejercicio 3
    function deshacer() {


      const lista = document.getElementById("historial");
      
      let valor = lista.lastChild

    const display = document.getElementById("display");
    console.log(display.textContent); 

    let valorDisplay = display.textContent; 
   


      if ( valor == lista.lastChild){
      lista.removeChild(valor);
      valorDisplay = 0 ; 
        if ( valor != lista){
          alert ( " no hay mas resultados que borrar ")
        }
    }

    }

    document.querySelectorAll(".boton").forEach((boton) => {
      boton.addEventListener("click", () => {
        const valor = boton.textContent;
        switch (valor) {
          case "C":
            borrar();
            break;
          case "←":
            retroceder();
            break;
          case "=":
            calcular();
            break;
          default:
            agregar(valor);
            break;
        }
      });
    });

    botonDeshacer.addEventListener("click", deshacer);
  }
});

