/*  
    Desarrollo web en entorno cliente
    DAW Distancia - Curso 24-25
    Examen UD7 - 250521
*/

document.addEventListener("DOMContentLoaded", function () {

 // Crear la solicitud AJAX

 
})