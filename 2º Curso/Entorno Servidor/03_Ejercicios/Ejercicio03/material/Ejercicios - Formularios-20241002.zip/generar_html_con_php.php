<?php
/*
Enunciado: Crea una página web que muestre una lista de elementos generados dinámicamente desde una matriz en PHP.
*/

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Elementos PHP</title>
</head>

<body>
    <h1 style="color: red;">Ejemplo 1 </h1>
    <h1>Lista de Elementos</h1>
    <ul>
        <?php
        $elementos = array("Manzana", "Banana", "Cereza", "Damasco");
        foreach ($elementos as $valor) {
            echo "<li> $valor </li>";
        }
        ?>
    </ul>
</body>

</html>

<?php


/*
Ejemplo 2: Usar estructuras de control en HTML
Supongamos que deseas mostrar una lista de elementos utilizando un bucle foreach en PHP dentro de una tabla HTML:
*/

?>

<?php
$frutas = array("Manzana", "Banana", "Cereza", "Damasco");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Lista de Frutas</title>
    <style>
        table,
        tr,
        th,
        td {
            border: 1px solid red;

        }

        .tabla {
            background-color: yellow;
        }
    </style>
</head>

<body>
    <h1 style="color: red;">Ejemplo 2 </h1>
    <h1>Lista de Frutas</h1>
    <table class="tabla">
        <tr>
            <th>Fruta</th>
        </tr>
        <?php foreach ($frutas as $fruta): ?>
            <!--No es necesario usar las llaves {}. En su lugar, puedes usar : para abrir el bloque y endforeach para cerrarlo. Esto se llama "sintaxis alternativa". Solo es válida cuando se usa dentro de un archivo PHP.-->
            <tr>
                <td style="padding-left: 20px; color: green;">
                    <?php echo $fruta ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

</body>

</html>

<?php
/*
Ejemplo 3: Condicionales en PHP para mostrar contenido HTML
Mostrar diferentes mensajes en función de una condición en PHP
*/
?>

<?php
$edad = 25;
?>

<!DOCTYPE html>
<html>

<head>
    <title>Mensaje de Saludo</title>
</head>

<body>
    <h1 style="color: red;">Ejemplo 3 </h1>


    <?php if ($edad < 18): ?>
        <p>Eres menor de edad.</p>
    <?php else: ?>
        <p>Eres mayor de edad.</p>
    <?php endif; ?>
</body>

</html>




<?php
/*
Crear una tabla HTML que muestra información sobre ciclos y módulos almacenados en un array multidimensional en PHP. Además, utilizar funciones PHP para procesar estos datos y generar la tabla de manera dinámica.
*/
?>
<!DOCTYPE html>
<html>

<head>
    <title>Ciclos y módulos</title>
</head>

<body>
    <h1 style="color: red;">Ejemplo 4 </h1>
    <h1>Ciclos y módulos</h1>

    <?php
    // Array multidimensional con información de ciclos y módulos
    $carballeira = [
        array("Nombre" => "SMR", "Módulos" => "MME", "Año" => '1º'),
        array("Nombre" => "FPB", "Módulos" => "Operaciones auxiliares", "Año" => '1º'),
        array("Nombre" => "DAW", "Módulos" => "Diseño de interfaces", "Año" => '2º'),

    ];

    // Función para mostrar la tabla
    function mostrarTabla($carballeira)
    {
        echo '<table>';
        echo '<tr><th>Nombre</th><th>Módulos</th><th>Año</th></tr>';
        foreach ($carballeira as $ciclo) {
            echo '<tr>';
            echo '<td>' . $ciclo["Nombre"] . '</td>';
            echo '<td>' . $ciclo["Módulos"] . '</td>';
            echo '<td>' . $ciclo["Año"] . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    }

    // Mostrar la tabla llamando a la función
    mostrarTabla($carballeira);
    ?>
</body>

</html>


<?php

//----------------------------------------------------------------------------------------------------------
//---------------------------------- Ejercicios ------------------------------------------------------------

/*
Enunciado:

"Un pequeño negocio de comida para llevar llamado 'Sabores Caseros' necesita un programa simple que muestre su menú y permita que los clientes realicen pedidos en línea. Se te pide que diseñes un programa en PHP que utilice un array para gestionar el menú, genere dinámicamente el código HTML del menú y permita a los clientes realizar pedidos a través de un formulario. A continuación, se presentan las pautas para esta tarea:

Pautas para el Alumno:

Parte 1: Gestión del Menú

Crea un array llamado $menu que contenga los nombres de los productos y sus precios.
Parte 2: Generación del Menú en HTML

Utiliza un bucle para recorrer el array $menu y generar dinámicamente el código HTML que muestra el menú en una lista desordenada (<ul>).

Parte 3: Formulario de Pedido

Crea un formulario HTML que permita a los clientes seleccionar productos del menú y especificar la cantidad deseada para cada producto.

Parte 4: Procesamiento del Pedido

En el servidor (PHP), procesa los datos enviados por el formulario y muestra un resumen del pedido realizado, incluyendo los productos seleccionados y el monto total del pedido.
*/

//Parte 1: Gestión del Menú


$menu = array(
    "Hamburguesa" => 5.99,
    "Pizza" => 8.99,
    "Ensalada" => 4.99,
    "Papas Fritas" => 2.99
);

// Parte 2 y 3 : Generación del Menú en HTML y formulario

?>

<!DOCTYPE html>
<html>

<head>
    <title>Menú de 'Sabores Caseros'</title>
    <link rel="stylesheet" href="bootstrap.css">
</head>

<body>
    <h1>Menú de 'Sabores Caseros'</h1>
    <ul>
        <?php foreach ($menu as $producto => $precio): ?>
            <li>
                <?php echo $producto; ?> - $
                <?php echo $precio; ?>
            </li>
        <?php endforeach; ?>
    </ul>

    <h2>Realizar Pedido:</h2>
    <form method="post">
        <label for="producto">Producto:</label>
        <select name="producto" id="producto">
            <?php foreach ($menu as $producto => $precio): ?>
                <option value="<?php echo $producto; ?>">
                    <?php echo $producto; ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br>
        <label for="cantidad">Cantidad:</label>
        <input type="number" name="cantidad" id="cantidad" min="1" required>
        <br>
        <input type="submit" value="Realizar Pedido">
    </form>
</body>

</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $producto = $_POST["producto"];
    $cantidad = (int) $_POST["cantidad"];

    if (array_key_exists($producto, $menu)) {
        $precio = $menu[$producto];
        $total = $precio * $cantidad;

        echo "<h3>Resumen del Pedido:</h3>";
        echo "Producto: $producto<br>";
        echo "Cantidad: $cantidad<br>";
        echo "Monto Total: $total euros";
    } else {
        echo "Producto no válido.";
    }
}
?>