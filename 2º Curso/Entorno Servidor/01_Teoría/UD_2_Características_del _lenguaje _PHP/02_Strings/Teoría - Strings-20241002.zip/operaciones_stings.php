<?php

$cadena = "Ejemplo de cadena";
$longitud = strlen($cadena);
echo "La longitud de la cadena es: " . $longitud . "<br>";

//Mayúsculas y Minúsculas:
echo strtoupper($cadena) . "<br>"; // Mayúsculas
echo strtolower($cadena) . "<br>"; // Minúsculas



//Reemplazar Subcadenas:
//Enunciado: Dada una cadena con la palabra "manzana", reemplaza "manzana" por "pera" y muestra el resultado.
$count = 0;
$cadena = "Me gusta la manzana roja.";
$nuevaCadena = str_replace("manzana", "pera", $cadena, $count);
echo $cadena . "<br>";
echo $nuevaCadena . "<br>";
echo "Se han realizado $count reemplazos" . "<br>";



//Cortar una Cadena:
//Enunciado: Toma una cadena y muestra solo los primeros 5 caracteres.
$cadena = "12345678";
$subcadena = substr($cadena, 0, 5);
echo $subcadena . "<br>";



//Buscar una Subcadena:
//Enunciado: Encuentra la posición de la subcadena "mundo" en la cadena "Hola, mundo!" y muestra el resultado.
$cadena = "Hola, mundo!.  Yo soy el mundo";
$posicion = strpos($cadena, "mundo", 15); //  Si se coloca el $offset, se puede buscar a partir de un desplazamiento. Buscaría el 2º "mundo"
echo "La subcadena 'mundo' comienza en la posición $posicion " . "<br>";



//Comprobar si una Cadena Comienza con ciertos caracteres:
//Enunciado: Dada una cadena, verifica si comienza con "http://" y muestra si es una URL válida.
$cadena = "http://www.ejemplo.com";
if (strpos($cadena, "http://") === 0) { //Está al comienzo
    echo "Es una URL válida." . "<br>";
} else {
    echo "No es una URL válida." . "<br>";
}

//Contar palabras en un Párrafo:
//Enunciado: Dado un párrafo, cuenta cuántas palabras contiene y muestra el resultado.
$parrafo = "Este es un ejemplo de párrafo con varias palabras.";
$palabras = str_word_count($parrafo, 2); //Convierte el string en un array asociativo
var_dump($palabras);
echo "<br>";
echo "<br>";
//echo "El párrafo contiene $palabras palabras." . "<br>";


//Dividir una Cadena en un Array:
//Enunciado: Divide una cadena en palabras individuales y almacénalas en un array, luego muestra cada palabra.
$cadena = "Esto es una prueba";
$palabras = explode(" ", $cadena, 2); //Crea dos arrays
foreach ($palabras as $valor) {
    echo $valor . "<br>";
}



//Generar un correo electrónico con Heredoc:
//Enunciado: Crea un correo electrónico utilizando la notación Heredoc y muestra su contenido.
$destinatario = "correo@example.com";
$asunto = "Saludo";
// La elección de la etiqueta EOD es arbitraría; No introducir nada a continuación de ella
$mensaje = <<<EOD
Hola,

Este es un correo de prueba.
Gracias.
EOD;
mail($destinatario, $asunto, $mensaje); //Nos va a mostrar una advertencia de que el Servidor SMTP no está configurado
echo $mensaje;
echo "<br>";
echo "<br>";


//Crear un fragmento de código con Nowdoc:
//Enunciado: Define un fragmento de código PHP utilizando Nowdoc y ejecútalo. Al introducir comillas simples, con el echo muestra el nombre de la variable
$nombre = "Juan";
$codigo = <<<'EOD'
echo "Hola, $nombre";
EOD;
echo $codigo; 
eval($codigo);
echo "<br>";
echo "<br>";


//Validar una Dirección de Correo Electrónico:
//Enunciado: Valida si una cadena es una dirección de correo electrónico válida.
$email = "correo@example.com";
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
  echo "La dirección de correo es válida.";
} else {
  echo "La dirección de correo no es válida.";
}

echo "<br>";


//Formatear una Fecha con sprintf:
//Enunciado: Formatea una fecha (por ejemplo, 26 de octubre de 2023) utilizando sprintf y muestra el resultado.
$dia = 26;
$mes = "octubre";
$anio = 2023;
$fecha = sprintf("%d de %s de %d", $dia, $mes, $anio);
echo $fecha;
echo "<br>";

//Eliminar Espacios en Blanco al Inicio y al Final:
//Enunciado: Dada una cadena con espacios en blanco al principio y al final, elimina estos espacios y muestra el resultado.
$cadena = "    Esto es una cadena con espacios    ";
$cadena = trim($cadena);
echo $cadena;
echo "<br>";

//Encontrar la Palabra Más Larga en un Párrafo:
//Enunciado: Encuentra la palabra más larga en un párrafo y muestra esa palabra.

$parrafo = "Este es un párrafo con palabras de diferentes longitudes.";
$palabras = explode(" ", $parrafo);
$palabraMasLarga = "";
foreach ($palabras as $palabra) {
  if (strlen($palabra) > strlen($palabraMasLarga)) {
    $palabraMasLarga = $palabra;
  }
}
echo "La palabra más larga es: $palabraMasLarga";
echo "<br>";
