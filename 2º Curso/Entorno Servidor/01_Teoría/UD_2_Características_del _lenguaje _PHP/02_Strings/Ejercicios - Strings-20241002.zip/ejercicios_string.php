<?php 

/*
**Ejercicio 1: Revertir una cadena**
Enunciado: Escribe un programa que tome una cadena y la imprima al revés.
$cadena = "Hola, mundo!";
*/

$cadena = "Hola, mundo!";
$cadenaRevertida = strrev($cadena);
echo "Cadena original: $cadena";
echo "<br>";
echo "Cadena revertida: $cadenaRevertida";
echo "<br>";
echo "<br>";
/*
**Ejercicio 2: Convertir a mayúsculas la primera letra de cada palabra en una frase**
Enunciado: Escribe un programa que tome una frase y convierta la primera letra de cada palabra a mayúsculas.
Hazlo con array_map y directamente
*/

$frase = "esto es un ejemplo de capitalización de palabras";
$palabras = explode(" ", $frase);

//Con array_map
$capitalizado = array_map('ucwords', $palabras);
$fraseCapitalizada = implode(" ", $capitalizado);
echo "Frase original: $frase";
echo "<br>";
echo "Frase capitalizada: $fraseCapitalizada";
echo "<br>";
echo "<br>";
//Directamente
echo ucwords(str_replace("_"," ", $fraseCapitalizada));
echo "<br>";
echo "<br>";



/*
**Ejercicio 3: Reemplazar todas las vocales en una cadena**
Enunciado: Escribe un programa que tome una cadena y reemplace todas las vocales por el carácter '*'.
$cadena = "Esta es una cadena con vocales";
*/

$cadena = "Esta es una cadena con vocales";
$cadenaReemplazada = str_replace(['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'], '*', $cadena);
echo "Cadena original: $cadena";
echo "<br>";
echo "Cadena con vocales reemplazadas: $cadenaReemplazada";
echo "<br>";
echo "<br>";

/*
**Ejercicio 4: Comprobar si una cadena contiene solo dígitos numéricos**
Enunciado: Escribe un programa que tome una cadena y verifique si contiene solo dígitos numéricos.
*/

$cadena1 = "12345";
$cadena2 = "12abc34";
if (ctype_digit($cadena1)) {
    echo "$cadena1 contiene solo dígitos numéricos";
} else {
    echo "$cadena1 no contiene solo dígitos numéricos";
}
echo "<br>";
echo "<br>";
if (ctype_digit($cadena2)) {
    echo "$cadena2 contiene solo dígitos numéricos";
} else {
    echo "$cadena2 no contiene solo dígitos numéricos";
}
echo "<br>";
echo "<br>";


/*
**Ejercicio 5: Eliminar espacios en blanco al inicio y final de una cadena**
Enunciado: Escribe un programa que tome una cadena y elimine los espacios en blanco al principio y al final.
$cadena = "  Espacios en blanco  ";
*/

$cadena = "  Espacios en blanco  ";
$cadenaLimpia = trim($cadena);
echo "Cadena original: '$cadena'";
echo "<br>";
echo "Cadena sin espacios en blanco: '$cadenaLimpia'";
echo "<br>";
echo "<br>";

/*
**Ejercicio 6: Contar la cantidad de palabras en una frase**
Enunciado: Escribe un programa que tome una frase y cuente la cantidad de palabras en ella.
$frase = "Este es un ejemplo de conteo de palabras.";
*/

$frase = "Este es un ejemplo de conteo de palabras.";
$palabras = str_word_count($frase);
echo "Frase: '$frase'";
echo "Cantidad de palabras: $palabras";
echo "<br>";
echo "<br>";


/*
**Ejercicio 7: Reemplazar espacios en blanco con guiones bajos en una URL**
Enunciado: Escribe un programa que tome una URL con espacios en blanco y reemplace los espacios por guiones bajos.
$url = "https://mi sitio web.com/página de inicio";
*/

$url = "https://mi sitio web.com/página de inicio";
$urlLimpia = str_replace(' ', '_', $url);
echo "URL original: '$url'";
echo "<br>";
echo "URL con guiones bajos: '$urlLimpia'";
echo "<br>";
echo  "<br>";


/*
**Ejercicio 8: Validar un correo electrónico**
Enunciado: Escribe un programa que valide si una dirección de correo electrónico es válida. Para ello, verifica que la cadena cumpla con el formato de un correo electrónico.
Escribe la función validarCorreoElectronico
$correo1 = "correo@example.com";
$correo2 = "correoinvalido";
*/

function validarCorreoElectronico($correo) {
    if (filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        return true;
    } else {
        return false;
    }
}

$correo1 = "correo@example.com";
$correo2 = "correoinvalido";
if (validarCorreoElectronico($correo1)) {
    echo "$correo1 es un correo electrónico válido.";
} else {
    echo "$correo1 no es un correo electrónico válido.";
}

if (validarCorreoElectronico($correo2)) {
    echo "$correo2 es un correo electrónico válido.";
} else {
    echo "$correo2 no es un correo electrónico válido.";
}

echo "<br>";
echo  "<br>";

/*
**Ejercicio 9: Validar una contraseña segura**
Enunciado: Escribe un programa que valide si una contraseña es segura. Para ello, verifica que la contraseña tenga al menos 8 caracteres, contenga al menos una letra mayúscula, una letra minúscula y un número.
function validarContrasenaSegura($contrasena)
$contrasena1 = "Segura123";
$contrasena2 = "12345";
*/

function validarContrasenaSegura($contrasena) {
    if (strlen($contrasena) >= 8 &&
        preg_match('/[A-Z]/', $contrasena) &&
        preg_match('/[a-z]/', $contrasena) &&
        preg_match('/[0-9]/', $contrasena)) {
        return true;
    } else {
        return false;
    }
}

$contrasena1 = "Segura123";
$contrasena2 = "12345";
if (validarContrasenaSegura($contrasena1)) {
    echo "$contrasena1 es una contraseña segura.";
} else {
    echo "$contrasena1 no es una contraseña segura.";
}

if (validarContrasenaSegura($contrasena2)) {
    echo "$contrasena2 es una contraseña segura.";
} else {
    echo "$contrasena2 no es una contraseña segura.";
}

/*
**Ejercicio 10: Validar un número de teléfono**
Enunciado: Escribe un programa que valide si un número de teléfono es válido. Para ello, verifica que la cadena contenga solo dígitos y tenga una longitud de 10 caracteres.
function validarNumeroTelefono($telefono)
$telefono1 = "1234567890";
$telefono2 = "12345abcd";
*/
function validarNumeroTelefono($telefono) {
    if (preg_match('/^[0-9]{10}$/', $telefono)) {
        return true;
    } else {
        return false;
    }
}

$telefono1 = "1234567890";
$telefono2 = "12345abcd";
if (validarNumeroTelefono($telefono1)) {
    echo "$telefono1 es un número de teléfono válido.";
} else {
    echo "$telefono1 no es un número de teléfono válido.";
}

if (validarNumeroTelefono($telefono2)) {
    echo "$telefono2 es un número de teléfono válido.";
} else {
    echo "$telefono2 no es un número de teléfono válido.";
}
