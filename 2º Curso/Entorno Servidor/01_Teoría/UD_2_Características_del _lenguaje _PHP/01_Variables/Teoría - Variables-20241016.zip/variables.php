<?php
// Variable escalar (cadena)
$nombre = "Juan";
echo "Hola, $nombre<br>";

// Variable escalar (entero)
$edad = 25;
echo "Tengo $edad años<br>";

// Variable escalar (flotante)
$precio = 19.99;
echo "El precio es $precio<br>";

// Variable booleana
$activo = true;
if ($activo) {
    echo "La cuenta está activa<br>";
} else {
    echo "La cuenta está inactiva<br>";
}

// Array indexado
$frutas = array("manzana", "plátano", "naranja");
echo "Mis frutas favoritas son {$frutas[0]}, {$frutas[1]} y {$frutas[2]}<br>";

// Array asociativo
$persona = array("nombre" => "María", "edad" => 30, "ciudad" => "Ciudad Ejemplo");
echo "Nombre: {$persona['nombre']}, Edad: {$persona['edad']}, Ciudad: {$persona['ciudad']}<br>";

// Variable superglobal ($_GET)
$id = $_GET['id']; // Supongamos que se obtiene un valor "id" de la URL
echo "El ID obtenido de la URL es $id<br>";

// Variable superglobal ($_POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_POST['correo']; // Supongamos que se obtiene un valor "correo" del formulario POST
    echo "El correo ingresado en el formulario es $correo<br>";
}

// Variable superglobal ($_SESSION)
session_start();
$_SESSION['usuario'] = "johndoe"; // Establecemos una variable de sesión
echo "El usuario en la sesión es {$_SESSION['usuario']}<br>";
?>
