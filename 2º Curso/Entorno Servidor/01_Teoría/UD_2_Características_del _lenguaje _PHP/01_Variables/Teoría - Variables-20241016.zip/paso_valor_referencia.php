<?php
$num1 = 100;
// Asignación por referencia. No le pasa un valor en concreto, sino la dirección de memoria donde se almacena num1
$num2_ref = &$num1;

// Asignación por valor o copia. Ahora se pasa lo que vale la variable num1
$num3_valor = $num1;

echo 'Valor de $num2_ref es: ' ,  $num2_ref , "<br>"; 
echo 'Valor de $num3_valor es: ' ,  $num3_valor , "<br>"; 

// Ahora modificamos num1
$num1 =500;

echo 'Valor de $num2_ref es: ' ,  $num2_ref , "<br>"; 
echo 'Valor de $num3_valor es: ' ,  $num3_valor , "<br>";