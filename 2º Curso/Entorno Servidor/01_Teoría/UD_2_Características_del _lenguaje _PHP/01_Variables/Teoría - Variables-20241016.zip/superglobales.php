<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="bootstrap.css">
    <title>Ejemplos de Superglobales en PHP</title>
</head>
<body>
    <h1>Formulario para Interactuar con Superglobales en PHP</h1>
    <form method="post" action="">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" id="nombre"><br>
        
        <label for="correo">Correo Electrónico:</label>
        <input type="email" name="correo" id="correo"><br>
        
        <label for="edad">Edad:</label>
        <input type="number" name="edad" id="edad"><br>
        
        <label for="archivo">Subir Archivo:</label>
        <input type="file" name="archivo" id="archivo"><br>
        
        <input type="submit" value="Enviar">
    </form>

    <?php
    // Procesamiento de las superglobales después de enviar el formulario
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // $_POST: Datos enviados a través de una solicitud POST
        echo "<h2>Datos de la solicitud POST:</h2>";
        if (isset($_POST['nombre'])) {
            $nombre = $_POST['nombre'];
            echo "Nombre: " . $nombre . "<br>";
        } else {
            echo "Nombre no especificado en la solicitud POST.<br>";
        }

        // $_FILES: Manejo de archivos enviados a través de una solicitud POST
        echo "<h2>Subida de Archivos:</h2>";
        if (isset($_FILES['archivo'])) {
            $nombreArchivo = $_FILES['archivo']['name'];
            echo "Nombre del archivo: " . $nombreArchivo . "<br>";
        } else {
            echo "Ningún archivo subido.<br>";
        }

        // Iniciar o restaurar la sesión para usar $_SESSION
        session_start();
        $_SESSION['usuario'] = 'ejemplo_usuario';

        // $_SESSION: Variables de sesión
        echo "<h2>Variables de Sesión:</h2>";
        echo "Usuario: " . $_SESSION['usuario'] . "<br>";

        // $_COOKIE: Datos de cookies enviados por el cliente
        if (isset($_COOKIE['idioma'])) {
            $idioma = $_COOKIE['idioma'];
            echo "<h2>Datos de Cookies:</h2>";
            echo "Idioma seleccionado: " . $idioma . "<br>";
        } else {
            echo "<h2>Datos de Cookies:</h2>";
            echo "Idioma no especificado en las cookies.<br>";
        }
    }
    ?>

</body>
</html>
