
<?php


/* 
Variables Locales:

Las variables locales son variables que solo están disponibles dentro de la función donde se declaran.
*/
function funcionLocal() {

    $variableLocal = "Soy una variable local.";
    echo $variableLocal . "<br>";
}

funcionLocal(); // Imprime: Soy una variable local.
echo $variableLocal . "<br>"; // Esto generará un error, $variableLocal no está definida fuera de la función.

/*
Variables Globales:

Las variables globales son variables que se definen fuera de las funciones y están disponibles en cualquier parte del script.
El uso de la palabra clave global dentro de una función en PHP es necesario cuando deseas acceder y modificar una variable global desde el interior de una función. Las variables globales son variables que se definen fuera de las funciones y, por defecto, no son visibles dentro del ámbito local de una función.

Cuando declaras una variable como global dentro de una función, estás informando a PHP que deseas utilizar la variable global en lugar de declarar una variable local con el mismo nombre. Esto permite que la función acceda y modifique el valor de la variable global en lugar de crear una variable local con un alcance limitado solo a la función.
Si no utilizas la palabra clave global dentro de la función, PHP creará una variable local con el mismo nombre en lugar de acceder a la variable global.
*/

$variableGlobal = "Soy una variable global.";

function funcionGlobal() {
    global $variableGlobal;
    echo $variableGlobal . "<br>";
}

funcionGlobal(); // Imprime: Soy una variable global.
echo $variableGlobal . "<br>" ; // Imprime: Soy una variable global.

/* 
Variables Estáticas:

Las variables estáticas son variables locales que conservan su valor entre llamadas a la función.
*/
function funcionEstatica() {
    static $contador = 0;
    $contador++;
    echo "Llamada número: $contador<br>";
}

funcionEstatica(); // Imprime: Llamada número: 1
funcionEstatica(); // Imprime: Llamada número: 2
funcionEstatica(); // Imprime: Llamada número: 3

/*
Ámbito Anidado:

Las funciones pueden acceder a variables en su ámbito local y en ámbitos superiores, como el ámbito global.
*/
$variableGlobal = "Soy una variable global.";

function funcionAnidada() {
    $variableLocal = "Soy una variable local.";
    echo $variableLocal . "<br>";
    global $variableGlobal;
    echo $variableGlobal . "<br>";
}

funcionAnidada(); // Imprime: Soy una variable local. Seguido de Soy una variable global.

/*
Variables Superglobales:

PHP también tiene variables superglobales que están disponibles en todos los ámbitos y no necesitas declararlas como globales. Ejemplos de superglobales incluyen $_POST, $_GET, $_SESSION, entre otras.
Aquí hay algunas de las variables superglobales más comunes en PHP y su estructura:

$_GET: Almacena datos enviados a través del método GET en una solicitud HTTP. Es un array asociativo donde las claves son los nombres de los parámetros y los valores son los valores pasados en la URL.
$_POST: Almacena datos enviados a través del método POST en una solicitud HTTP. Al igual que $_GET, es un array asociativo.
$_SESSION: Almacena variables de sesión, que son variables que pueden persistir a lo largo de múltiples solicitudes del mismo usuario. Es un array asociativo.
$_COOKIE: Almacena cookies enviadas por el cliente al servidor. También es un array asociativo.
$_REQUEST: Almacena datos tanto de GET como de POST, así como de cookies. Es un array que combina información de diferentes fuentes de datos.

$_SERVER: Almacena información sobre el servidor web y el entorno de ejecución. Es un array asociativo con claves como "HTTP_USER_AGENT", "SERVER_NAME", "REQUEST_METHOD", etc.

$_FILES: Almacena información sobre archivos subidos a través de formularios HTML que utilizan el atributo enctype="multipart/form-data". Es un array asociativo que contiene detalles sobre el archivo, como nombre, tipo, tamaño, etc.

$_ENV: Almacena información sobre variables de entorno del servidor.

$_GLOBALS: Contiene todas las variables globales.

$_SESSION: Almacena variables de sesión.
*/
$_POST['nombre'] = "Juan";

function obtenerNombre() {
    echo $_POST['nombre'] . "<br>";
}

obtenerNombre(); // Imprime: Juan


?>