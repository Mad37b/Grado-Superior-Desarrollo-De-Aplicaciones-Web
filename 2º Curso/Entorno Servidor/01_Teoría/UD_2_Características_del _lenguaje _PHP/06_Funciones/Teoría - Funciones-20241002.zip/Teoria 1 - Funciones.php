<?php
// Función simple sin parámetros ni valor de retorno
function saludar()
{
    echo "¡Hola, mundo!<br>";
}

saludar(); // Llamada a la función

// Función con parámetros y valor de retorno
function factorial($n)
{
    $resultado = 1;
    for ($i = 1; $i <= $n; $i++) {
        $resultado *= $i;
    }
    return $resultado;
}

$numero = 5;
$factorial = factorial($numero); // Llamada a la función y almacenamiento del resultado
echo "El factorial de $numero es $factorial.<br>";

////////////////////////////////////////////////////////////////
//Manejar variables externas con parámetros
function manejarVariablesExternas($variableExterna)
{
    $variableExterna = 5;
    echo "Valor de la variable externa dentro de la función: " . $variableExterna . "<br>";
    return $variableExterna;
}

$variableExterna = 0; // Variable externa
echo "Valor de la variable externa antes de llamar a la función es: " . $variableExterna . "<br>";

$variableExterna = manejarVariablesExternas($variableExterna) + 5; // Llama a la función y actualiza la variable
echo "Valor de la variable externa fuera de la función: " . $variableExterna;



//Manejar variables externas con paso por referencia
function manejarVariableExternaPorReferencia(&$variableExternaRef) { //prueba a quitar el & para ver que no te da bien 
    $variableExternaRef += 5; // Modificar la variable externa directamente
    echo "Valor de la variable externa dentro de la función: " . $variableExternaRef . "<br>";
}

$variableExternaRef = 10; // Variable externa
manejarVariableExternaPorReferencia($variableExternaRef); // Llama a la función por referencia
echo "Valor de la variable externa fuera de la función: " . $variableExternaRef;

// Función con valor de retorno por referencia
function duplicar(&$valor)
{
    $valor *= 2;
}

$numeroDuplicar = 7;
duplicar($numeroDuplicar);
echo "El número duplicado es $numeroDuplicar.<br>";



//Manejar variables externas con funciones anónimas o cierres o closures

$variableExternaFunAnon = 10;

/*
Usamos use (&$variableExterna) para capturar la variable externa por referencia dentro de la función anónima. Esto significa que cualquier modificación realizada en la variable dentro de la función anónima se reflejará en la variable externa.
*/
$manejarVariableExterna = function () use (&$variableExternaFunAnon){
    $variableExternaFunAnon += 5 ; // Modificar la variable externa
    echo "Valor de la variable externa dentro de la función anónima: " . $variableExternaFunAnon . "<br>";

};

echo "Valor de la variable externa fuera de la función anónima, antes de llamarla: " . $variableExternaFunAnon . "<br>";
$manejarVariableExterna(); // Llama a la función anónima
echo "Valor de la variable externa fuera de la función anónima: " . $variableExternaFunAnon;


///////////////////////////////////////////////////////////////////////////////////////////////////////
// Función con valor de retorno múltiple usando un array
function obtenerInformacion($nombre)
{
    $edad = 30;
    $ciudad = "Ejemploville";
    return [$nombre, $edad, $ciudad];
}

$informacion = obtenerInformacion("Juan");
echo "Nombre: " . $informacion[0] . ", Edad: " . $informacion[1] . ", Ciudad: " . $informacion[2] . "<br>";




// Función recursiva para mostrar números del 1 al 5
function mostrarNumeros($n)
{
    if ($n > 0) {
        mostrarNumeros($n - 1);
        echo "$n ";
    }
}

echo "Números del 1 al 5 usando una función recursiva: ";
mostrarNumeros(5);

//Funciones con declaración de tipo que devuelven

/*
A partir de PHP 7.0, puedes especificar el tipo de dato que una función debe devolver utilizando el tipo de retorno en la declaración de la función. 
*/

function sumar (int $a, int $b) : int {

    return $a +$b;
}

$resultado = sumar(5,3);
echo $resultado;