<?php

//Funciones simples 

// Función simple que suma dos números
function suma($a, $b) {
    return $a + $b;
}

$resultado = suma(5, 3);
echo "La suma es: $resultado"  . "<br>"; // Imprime: La suma es: 8

////////////////////////////////////////////////////////////////////////////////////////
//Funciones de Usuario:

// Declaración de una función de usuario
function saludar($nombre) {
    echo "Hola, $nombre!" . "<br>";
}

// Llamada a la función de usuario
saludar("Juan"); // Imprime: Hola, Juan!


/////////////////////////////////////////////////////////////////////////////////////////
//Funciones Recursivas:

// Función recursiva para calcular el factorial de un número
function factorial($n) {
    if ($n <= 1) {
        return 1;
    } else {
        return $n * factorial($n - 1);
    }
}

$factorialDe5 = factorial(5);
echo "El factorial de 5 es: $factorialDe5" . "<br>"; // Imprime: El factorial de 5 es: 120



/////////////////////////////////////////////////////////////////////////////////////////
//Funciones del Sistema (Built-in Functions):
// Función del sistema para obtener la longitud de una cadena

$longitud = strlen("Hola, mundo");
echo "La longitud de la cadena es: $longitud" . "<br>" ; // Imprime: La longitud de la cadena es: 12

//////////////////////////////////////////////////////////////////////////////////////////
//Funciones con Argumentos Predeterminados:
// Función con argumento predeterminado

function saluda($nombre = "Invitado") {
    echo "Hola, $nombre!";
}

saluda(); // Imprime: Hola, Invitado!
saluda("Juan"); // Imprime: Hola, Juan!

///////////////////////////////////////////////////////////////////////////////////////////
//Funciones con Número Variable de Argumentos (Argumentos Variables):

// Función con número variable de argumentos
function suma_varios(...$numeros) {
    $total = 0;
    foreach ($numeros as $numero) {
        $total += $numero;
    }
    return $total;
}

$resultado = suma_varios(2, 4, 6, 8);
echo "La suma es: $resultado" . "<br>"; // Imprime: La suma es: 20


/////////////////////////////////////////////////////////////////////////////////////////////
//Funciones Anónimas (Cierres - Closures):
/*
Los cierres, conocidos como "closures" en inglés o "funciones anónimas", son una característica poderosa en PHP y en muchos otros lenguajes de programación. Los cierres permiten crear funciones que pueden ser asignadas a variables, pasadas como argumentos a otras funciones y utilizadas de manera flexible en tu código.
Un cierre es una función que no tiene nombre y puede ser definida en el lugar donde se necesita, es decir, en el momento y el contexto en que se va a utilizar. Un cierre se define utilizando la sintaxis function() { // código del cierre  }. Los cierres pueden capturar y mantener el contexto (variables) en el que fueron creados, lo que les permite acceder a variables fuera de su alcance local
*/

//////////////////////////////////////////
//Ejemplo de Cierre Básico

/*//Se crea un cierre que acepta un parámetro $nombre y lo utiliza para imprimir un saludo personalizado. El cierre se asigna a la variable $saludo y luego se llama como si fuera una función normal.*/

$saludo = function ($nombre) {
    echo "Hola, $nombre!" . "<br>"; 
};

$saludo("Juan"); // Imprime: Hola, Juan!

///////////////////////////////////////////
//Captura de Variables Externas
/*
Los cierres tienen la capacidad de capturar y retener variables del entorno en el que fueron creados, incluso después de que ese entorno haya terminado. Esto se llama "captura léxica de variables" o "cierre de variables". 
En este ejemplo, el cierre $crearMensaje captura la variable $mensaje del entorno externo. Esto significa que aunque $mensaje ya no existe en el ámbito local del cierre, aún puede accederse a él debido a la captura léxica. Esto es útil para crear cierres que tienen acceso a variables externas de manera controlada.
*/
$mensaje = "Hola, ";

$crearMensaje = function ($nombre) use ($mensaje) {
    echo $mensaje . $nombre . "<br>";
};

$crearMensaje("Juan"); // Imprime: Hola, Juan

////////////////////////////////////////////////
//Utilización de Cierres en Funciones de Orden Superior
/*Los cierres son especialmente útiles cuando se trabajan con funciones de orden superior, que son funciones que aceptan otras funciones como argumentos o devuelven funciones. Un ejemplo común de esto es el uso de la función array_map() para aplicar una función a cada elemento de un array.
En este caso, hemos pasado un cierre anónimo como argumento a array_map(). Este cierre se ejecutará en cada elemento del array $numeros y devolverá un nuevo array con los cuadrados de los números
*/

$numeros = [1, 2, 3, 4, 5,6];

$cuadrados = array_map(function ($numero) {
    return $numero * $numero;
}, $numeros);

print_r($cuadrados); // Imprime: Array ( [0] => 1 [1] => 4 [2] => 9 [3] => 16 [4] => 25 )

