<?php 
/*
//Enunciado: Crea una función que acepte un número variable de argumentos y devuelva su suma.<?php
function sumar(...$numeros) {
    return array_sum($numeros);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $resultado = sumar($_POST['numero1'], $_POST['numero2']);
    echo "La suma es: $resultado";
}
?>

<form method="post">
    <label for="numero1">Número 1:</label>
    <input type="number" name="numero1" required>

    <label for="numero2">Número 2:</label>
    <input type="number" name="numero2" required>

    <label for="numero3">Número 3:</label>
    <input type="number" name="numero3" required>

    <button type="submit">Calcular Suma</button>
</form>
*/?>
<?php
//Enunciado: Crea una función que calcule la potencia de un número, permitiendo que el exponente sea opcional y asumiendo un valor predeterminado de 2 si no se proporciona.
/*
function potencia($base, $exponente = 2) {
    // Convertir las cadenas a números si están definidas y no son cadenas vacías
    $base = isset($base) ? (float)$base : 0;
    $exponente = isset($exponente) && $exponente !== '' ? (float)$exponente : 2;

    return pow($base, $exponente);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $resultado = potencia($_POST['base'], $_POST['exponente']);
    echo "El resultado de la potencia es: $resultado";
}
?>

<form method="post">
    <label for="base">Base:</label>
    <input type="text" name="base" required>

    <label for="exponente">Exponente:</label>
    <input type="text" name="exponente">

    <button type="submit">Calcular Potencia</button>
</form>
*/
?>

<?php
/*
$realizarOperacion = function ($a, $b, $operador) {
    switch ($operador) {
        case 'suma':
            return $a + $b;
        case 'resta':
            return $a - $b;
        case 'multiplicacion':
            return $a * $b;
        case 'division':
            return ($b != 0) ? $a / $b : "No se puede dividir por cero.";
        default:
            return "Operador no válido";
    }
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $numero1 = $_POST['numero1'];
    $numero2 = $_POST['numero2'];
    $operador = $_POST['operador'];

    $resultado = $realizarOperacion($numero1, $numero2, $operador);
    echo "El resultado de la operación es: $resultado";
    
}
?>

<form method="post">
    <label for="numero1">Número 1:</label>
    <input type="number" name="numero1" required>

    <label for="numero2">Número 2:</label>
    <input type="number" name="numero2" required>

    <label for="operador">Operador:</label>
    <select name="operador" required>
        <option value="suma">Suma (+)</option>
        <option value="resta">Resta (-)</option>
        <option value="multiplicacion">Multiplicación (*)</option>
        <option value="division">División (/)</option>
    </select>

    <button type="submit">Realizar Operación</button>
</form>
*/
?>

<?php 
//Enunciado: Crea una función anónima que multiplique un número por un factor. Utiliza use para permitir cambiar dinámicamente el factor de multiplicación.
/*
$factorExterno = 6;

$multiplicarPorFactor = function ($numero) use ($factorExterno) {
    return $numero * $factorExterno;
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $numero = $_POST['numero'];

    $resultado = $multiplicarPorFactor($numero);
    echo "El resultado de la multiplicación es: $resultado";
}
?>

<form method="post">
    <label for="numero">Número a multiplicar:</label>
    <input type="number" name="numero" required>

    <button type="submit">Multiplicar por Factor</button>
</form>
*/
?>
<?php 
//Enunciado: Crea una función que, dependiendo de una condición, realice un cálculo específico. Intenta invocar esta función antes de su declaración y observa el mensaje de error que se produce.


// Intento de invocar la función antes de su declaración
$resultado = calcularResultado(5, 3, true);

// Definición de la función dentro de un condicional
if (true) {
    function calcularResultado($a, $b, $condicion) {
        return $condicion ? $a + $b : $a - $b;
    }
}
/*En este ejemplo, se intenta invocar la función calcularResultado antes de su declaración. Sin embargo, debido a que la función está definida dentro de un bloque condicional (if), no será reconocida fuera de ese bloque.
*/
?>
