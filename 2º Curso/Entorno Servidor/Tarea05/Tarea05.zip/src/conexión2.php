<?php namespace Tarea05; ?>
<?php 
/** Tarea05 -  Conexion con PDO */

class conexion {
    private $PDO;

   
    public function obtenerConexion(){
    
    $usuario="root";
    $host="localhost";
    $nombreBD="Jugadores";
    $contraseña="";
    $conexion ="mysql:host=$host;dbname=$nombreBD;charset=utf8";

        try {
            echo"hola";
            $this->PDO = new \PDO($conexion, $usuario, $contraseña);
            
            if(isset($this->PDO) ){
            echo "<h3>Conexion establecida con la base de datos<h3><br><br>" ;
            }else { echo " No se ha establecido conexion con la base de datos";}

        } catch (\PDOException $e) {
            echo "<h3>Catch : No se ha establecido una base de datos: " . $e->getMessage()."<h3>";
        }
        return $this->PDO;
    }

}
$conexion = new conexion;
$establecer = $conexion->obtenerConexion();

if ($establecer) {
    echo "La conexión ha sido exitosa!";
    var_dump($establecer);
    echo "<br><br>";
    print_r($establecer);
} else {
    echo "Hubo un error al establecer la conexión.";
}
?>