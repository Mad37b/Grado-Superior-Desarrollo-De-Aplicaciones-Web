<?php namespace Tarea05; ?>

<?php

/** Consulta y obtiene los datos de los jugadores */

require 'conexión.php';
require 'conexión2.php';

if(isset($conexion)){
    echo"hay conexion";
}



class jugador {


    /** Variables de la base de datos */
    private $nombre;
    private $apellido;
    private $dorsal;
    private $codigoBarras;
    public $PDO;

    /** Variables para sql  */
 public function __construct($pdo) {
    $this->PDO = $pdo;
 }

/** get y query de jugadores */
public function obtenerJugadores (){

   $sqlQuery = " Select * FROM listajugadores";
   $estado = $this->PDO->prepare($sqlQuery);
   $estado->execute();
   return $estado->fetchAll();
}
public function insertarJugadores ($nombreParam,$apellidoParam,$dorsalParam,$codigoBarrasParam){
    $this->nombre = $nombreParam;
    $this->apellido = $apellidoParam;
    $this->dorsal = $dorsalParam;
    $this->codigoBarras = $codigoBarrasParam;
    
    $sqlInsert = "INSERT INTO 'listajugadores' ('Nombre' ,'Apellido', 'Dorsal',' Codigo_de_barras') VALUES (".$nombreParam.",".$apellidoParam.",".$dorsalParam.",".$codigoBarrasParam.")";
    $estado = $this->PDO->prepare($sqlInsert);
    $estado->execute();


}

public function actualizarJugadores($nombreParam,$apellidoParam,$dorsalParam,$codigoBarrasParam){
    $this->nombre = $nombreParam;
    $this->apellido = $apellidoParam;
    $this->dorsal = $dorsalParam;
    $this->nombre = $codigoBarrasParam;
    $sqlUpdate = " UPDATE 'listajugadores' SET ('Nombre' ,'Apellido', 'Dorsal',' Codigo_de_barras') WHERE (".$nombreParam.",".$apellidoParam.",".$dorsalParam.",".$codigoBarrasParam.")";
    $estado = $this->PDO->prepare($sqlUpdate);
    $estado->execute();

}
public function borrarJugadores($nombreParam,$apellidoParam,$dorsalParam,$codigoBarrasParam){
    $this->nombre = $nombreParam;
    $this->apellido = $apellidoParam;
    $this->dorsal = $dorsalParam;
    $this->nombre = $codigoBarrasParam;
    $sqlDelete = "DELETE FROM 'listajugadores' WHERE  (".$nombreParam.",".$apellidoParam.",".$dorsalParam.",".$codigoBarrasParam.")";
    $estado = $this->PDO->prepare($sqlDelete);
    $estado->execute();
}

}

/** Resultado de la consulta */

?>