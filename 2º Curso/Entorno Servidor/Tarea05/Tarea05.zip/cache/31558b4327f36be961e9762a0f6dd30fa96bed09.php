<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>vista Jugadores</title>
</head>
<body>
    <h1> pagina de vistaJugadores</h1>
    <h3>  Muestra la tabla de todos los jugadores </h3>
    <a><button href="fcrear.php" value="Fichar Jugador "></button></a>
    <table border="1">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Dorsal</th>
                <th>Código de Barras</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $jugadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jugador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($jugador->nombre); ?></td>
                <td><?php echo e($jugador->apellido); ?></td>
                <td><?php echo e($jugador->dorsal); ?></td>
                <td><?php echo e($jugador->codigo_barras); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </tbody>
    </table>

</body>
</html>