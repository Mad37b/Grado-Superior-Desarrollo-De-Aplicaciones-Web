<?php
/** está página es el "action" del formulario para crear un jugador. Controlaremos errores para no introducir un dorsal que ya existe, que nombre y apellidos no esté vacios**/
   
/** será un controlador de crear Jugadores con insert */
require_once __DIR__. "/../src/jugador.php";
require_once __DIR__. "/../src/config.php";
require_once __DIR__. "/../src/conexión.php";

use Tarea05\jugador;
use Tarea05\config;
use Tarea05\conexion;

class insertOneJugadorController{
public $pdo;

function __construct($pdo)
{
$this ->pdo = $pdo;
}
 
function agregarJugador($nombreParam,$apellido,$dorsalParam,$codigoBarrasParam){

/** instancia de la clase Jugador */

$insertarJugador = new jugador($this->pdo);
$insertarJugador->insertarJugadores($nombreParam,$apellido,$dorsalParam,$codigoBarrasParam);

 }

}

    if ( $_SERVER["REQUEST_METHOD"] == "POST"){

        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $dorsal = $_POST["dorsal"];
        $posición = $_POST ["posicion"];
        $codigobarras = $_POST["codigoBarras"];
        echo "<p> " . $nombre . "</p>";

        $this->nombre = $nombreParam;


        $añadirJugador = new insertOneJugadorController($pdo);
        $nuevoJugador = $añadirJugador->agregarJugador($nombreParam,$apellidoParam,$dorsalParam,$codigoBarrasParam);
    }

    /** Vista */

    $consultarJugadores = new jugador($pdo);
    $jugadoresCantera = $consultarJugadores->obtenerJugadores();


echo $blade->view()->make('vistajugadores', ['jugadores' => $jugadoresCantera])->render(); 