<?php
require_once __DIR__ . '/../src/config.php'; // Subir un nivel y acceder a src/config.php
require_once __DIR__ . '/../src/conexión.php';
require_once __DIR__ . '/../src/jugador.php';

use Tarea05\jugador;
use Tarea05\conexion;
/** llama a la vista vjugadores.php */
/**echo $blade->view()->make('vistaJugadores')->render();**/
/**Llama a la vista "vjugadores.php" Muestra en una tabla los datos de los jugadores. Tiene un botón crear que llama al formulario para crear un jugador nuevo. Si un jugador NO tiene dorsal mostraremos "Sin asignar".

/** llamar a los métodos */



class controllerJugadores {

    public $pdo;

    public function __construct($pdo){
        
  
      $this->pdo = $pdo ; 

    }


    public function controladorObtener (){
        
        $jugador = new jugador($this->pdo);
        $jugadores = $jugador->obtenerJugadores();
        return $jugadores;
    }
}

$conexion = new conexion();
$pdo = $conexion->obtenerConexion();

$controller = new controllerJugadores($pdo);
$jugadores = $controller->controladorObtener();


echo $blade->view()->make('vistaJugadores', ['jugadores' => $jugadores])->render();
 ?>