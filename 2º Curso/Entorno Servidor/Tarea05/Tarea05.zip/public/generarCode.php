<?php

/**Está página me genera un código de barras EAN-13 válido y que además no exista en la base de datos */
require '../vendor/autoload.php';
use \Milon\Barcode\DNS1D;
$codigo="9780691147727";
$d = new DNS1D();
$d->setStorPath(__DIR__.'/cache/');
echo $d->getBarcodeHTML($codigo, 'EAN13');
echo $d->getBarcodeHTML('4445645656', 'EAN13');
echo $d->getBarcodePNGPath('4445645656', 'PDF417');
echo $d->getBarcodeSVG('4445645656', 'DATAMATRIX');

?>
 