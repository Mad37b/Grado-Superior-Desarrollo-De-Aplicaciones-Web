<!-- views/vista.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Mi primera vista Blade</title>
</head>
<body>
    <h1>¡Hola, Blade funciona correctamente!</h1>
</body>
</html>
