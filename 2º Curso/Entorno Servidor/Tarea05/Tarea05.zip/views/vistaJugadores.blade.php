<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"   href="style.css">
    <title>vista Jugadores</title>
</head>
<body>
    <h1> pagina de vistaJugadores</h1>
    <h3>  Muestra la tabla de todos los jugadores </h3>
    <a><button href="fcrear.php" value="Fichar Jugador "></button></a>
    <table border="1">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Dorsal</th>
                <th>Código de Barras</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($jugadores as $jugador)
            <tr>
                <td>{{ $jugador['Nombre'] }}</td>
                <td>{{ $jugador['Apellido'] }}</td>
                <td>{{ $jugador['Dorsal'] }}</td>
                <td>{{ $jugador['Código_de_barras'] }}</td>
            </tr>
            @endforeach
            </tr>
        </tbody>
    </table>

</body>
</html>